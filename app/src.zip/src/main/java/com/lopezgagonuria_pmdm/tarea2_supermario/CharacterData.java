package com.lopezgagonuria_pmdm.tarea2_supermario;

public class CharacterData {
    private String nombre;
    private int imagen;
    private String descripcion;
    private String habilidades;

    // Constructor
    public CharacterData(String nombre, int imagen, String descripcion, String habilidades) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.descripcion = descripcion;
        this.habilidades = habilidades;
    }

    // Métodos getters
    public String getNombre() {
        return nombre;
    }

    public int getImagen() {
        return imagen;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getHabilidades() {
        return habilidades;
    }
}