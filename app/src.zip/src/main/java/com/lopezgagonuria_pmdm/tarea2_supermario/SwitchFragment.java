package com.lopezgagonuria_pmdm.tarea2_supermario;



import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Locale;

public class SwitchFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Infla el diseño del fragmento
        View view = inflater.inflate(R.layout.switch_fragment, container, false);

        // Inicializa el Switch con el ID del XML
        // Switch para cambiar el idioma
        @SuppressLint("UseSwitchCompatOrMaterialCode") Switch optionLanguageSwitch = view.findViewById(R.id.option_language_switch);

        // Obtén el estado actual del idioma desde las SharedPreferences
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("AppSettings", Context.MODE_PRIVATE);
        boolean isEnglish = sharedPreferences.getBoolean("isEnglish", false);
        optionLanguageSwitch.setChecked(isEnglish);

        // Maneja el cambio de idioma
        optionLanguageSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if (isChecked) {
                editor.putBoolean("isEnglish", true);
                setLocale("en"); // Cambia a inglés
            } else {
                editor.putBoolean("isEnglish", false);
                setLocale("es"); // Cambia a español
            }
            editor.apply();

            // Muestra un mensaje confirmando el cambio
            Toast.makeText(requireContext(), "Idioma cambiado", Toast.LENGTH_SHORT).show();
            requireActivity().recreate(); // Reinicia la actividad para aplicar los cambios
        });

        return view;
    }

    // Cambia el idioma de la app
    private void setLocale(String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        requireActivity().getResources().updateConfiguration(config, requireActivity().getResources().getDisplayMetrics());
    }
}
