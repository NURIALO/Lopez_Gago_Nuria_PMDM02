package com.lopezgagonuria_pmdm.tarea2_supermario;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.PersonajeViewHolder> {

    private Context context;
    private List<CharacterData> personajeList;
    private OnItemClickListener listener;

    public RecyclerviewAdapter(Context context, List<CharacterData> personajeList, OnItemClickListener listener) {
        this.context = context;
        this.personajeList = personajeList;
        this.listener = listener;
    }


    @Override
    public PersonajeViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.character_cardview, parent, false);
        return new PersonajeViewHolder(view);
    }

    @Override
    public void onBindViewHolder( PersonajeViewHolder holder, int position) {
        CharacterData personaje = personajeList.get(position);
        holder.textViewNombre.setText(personaje.getNombre());
        holder.imageViewPersonaje.setImageResource(personaje.getImagen());

        // Evento de clic para cada elemento
        holder.itemView.setOnClickListener(v -> listener.onItemClick(personaje));
    }

    @Override
    public int getItemCount() {
        return personajeList.size();
    }

    public static class PersonajeViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewPersonaje;
        TextView textViewNombre;

        public PersonajeViewHolder(View itemView) {
            super(itemView);
            imageViewPersonaje = itemView.findViewById(R.id.image_cardview);
            textViewNombre = itemView.findViewById(R.id.text_Cardview);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(CharacterData personaje);
    }
}